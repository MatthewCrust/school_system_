import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import AddClass from './components/AddClass';
import AddStudent from './components/AddStudent';
import AddGrade from './components/AddGrade';
import Login from './components/Login';
import Register from './components/Register';
import axios from 'axios';
import './App.css';

function App() {
  const [classes, setClasses] = useState([]);
  const [selectedClass, setSelectedClass] = useState(null);
  const [students, setStudents] = useState([]);
  const [selectedStudent, setSelectedStudent] = useState(null);
  const [grades, setGrades] = useState([]);
  const [average, setAverage] = useState(0);
  const [isLogin, setIsLogin] = useState(true);  
  const [isAuthenticated, setIsAuthenticated] = useState(false); 
  const [role, setRole] = useState('');


  useEffect(() => {
    if (isAuthenticated) {
      fetchClasses();
    }
  }, [isAuthenticated]);

  const fetchClasses = async () => {
    try {
      const response = await axios.get('http://localhost:3001/classes');
      setClasses(response.data);
    } catch (error) {
      console.error('Error fetching classes:', error);
    }
  };

  const fetchStudents = async (classId) => {
    try {
      const response = await axios.get(`/classes/${classId}/students`);
      setStudents(response.data);
      setSelectedStudent(null);
    } catch (error) {
      console.error('Error fetching students:', error);
    }
  };

  const fetchGrades = async (studentId) => {
    try {
      const gradesResponse = await axios.get(`http://localhost:3001/students/${studentId}/grades`);
      setGrades(gradesResponse.data);

      const averageResponse = await axios.get(`http://localhost:3001/students/${studentId}/average`);
      setAverage(averageResponse.data.average);
    } catch (error) {
      console.error('Error fetching grades:', error);
    }
  };

  useEffect(() => {
    const userId = 1; 

    axios.get(`http://localhost:3001/user/role/${userId}`)
        .then(response => {
            setRole(response.data.role); 
        })
        .catch(error => {
            console.error('Error fetching user role:', error);
        });
}, []);

  const handleClassSelect = (classId) => {
    setSelectedClass(classId);
    fetchStudents(classId);
  };

  const handleStudentSelect = (studentId) => {
    setSelectedStudent(studentId);
    fetchGrades(studentId);
  };

  const handleDeleteGrade = async (gradeId) => {
    try {
      await axios.delete(`http://localhost:3001/grades/${gradeId}`);
      alert('Grade deleted successfully');
      fetchGrades(selectedStudent);
    } catch (error) {
      console.error('Error deleting grade:', error);
      alert('Failed to delete grade');
    }
  };

  const handleDeleteStudent = async (studentId) => {
    try {
      await axios.delete(`http://localhost:3001/students/${studentId}`);
      alert('Student deleted successfully');
      fetchStudents(selectedClass);
      if (selectedStudent === studentId) {
        setSelectedStudent(null);
        setGrades([]);
        setAverage(0);
      }
    } catch (error) {
      console.error('Error deleting student:', error);
      alert('Failed to delete student');
    }
  };

  const handleAuthSuccess = () => {
    setIsAuthenticated(true);
  };

  const toggleForm = () => {
    setIsLogin(!isLogin);
  };

  return (
    <Router>
      <div className="App">
        <Routes>
          <Route path="/" element={ 
            !isAuthenticated ? (
              <div>
                <h2>{isLogin ? 'Login' : 'Register'}</h2>
                {isLogin ? <Login onAuthSuccess={handleAuthSuccess} /> : <Register onAuthSuccess={handleAuthSuccess} />}
                <button onClick={toggleForm}>
                  {isLogin ? 'Switch to Register' : 'Switch to Login'}
                </button>
              </div>
            ) : (
              <div>
                <h1>School Management System</h1>
                <AddClass fetchClasses={fetchClasses} />
                <h2>Select a Class</h2>
                <select onChange={(e) => handleClassSelect(e.target.value)} value={selectedClass || ''}>
                  <option value="" disabled>Select Class</option>
                  {classes.map(cls => (
                    <option key={cls.id} value={cls.id}>{cls.name}</option>
                  ))}
                </select>

                {selectedClass && (
                  <>
                    <h2>Students in Class</h2>
                    <AddStudent classId={selectedClass} fetchStudents={() => fetchStudents(selectedClass)} />
                    <ul>
                      {students.map(student => (
                        <li key={student.id}>
                          {student.name}
                          <button onClick={() => handleDeleteStudent(student.id)}>Delete</button>
                          <button onClick={() => handleStudentSelect(student.id)}>Show Grades</button>
                        </li>
                      ))}
                    </ul>
                  </>
                )}

                {selectedStudent && (
                  <>
                    <h2>Grades for {students.find(s => s.id === selectedStudent)?.name}</h2>
                    <AddGrade studentId={selectedStudent} fetchGrades={() => fetchGrades(selectedStudent)} />
                    <ul>
                      {grades.map(grade => (
                        <li key={grade.id}>
                          Grade: {grade.grade}, Weight: {grade.weight}, Description: {grade.description}
                          <button onClick={() => handleDeleteGrade(grade.id)}>Delete</button>
                        </li>
                      ))}
                    </ul>
                    <h3>Average Grade: {average.toFixed(2)}</h3>
                  </>
                )}
              </div>
            )
          } />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
