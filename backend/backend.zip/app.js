const express = require('express');
const bodyParser = require('body-parser');
const { queryDatabase } = require('./config/db'); 
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const app = express();
app.use(bodyParser.json());

const cors = require('cors');
app.use(cors());


app.get('/user/role/:userId', async (req, res) => {
    try {
        const { userId } = req.params;

        const [user] = await queryDatabase('SELECT role FROM users WHERE id = ?', [userId]);

        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }

        res.json({ role: user.role });
    } catch (error) {
        console.error('Error fetching user role:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});



app.post('/students', async (req, res) => {
    try {
        const { name, class_id } = req.body;
        
        if (!name || !class_id) {
            return res.status(400).json({ error: 'Name and class_id are required' });
        }

        await queryDatabase('INSERT INTO students (name, class_id) VALUES (?, ?)', [name, class_id]);

        res.status(201).json({ message: 'Student added successfully' });
    } catch (error) {
        console.error('Error adding student:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.get('/classes', async (req, res) => {
    try {
        const classes = await queryDatabase('SELECT id, name FROM classes');
        res.json(classes);
    } catch (error) {
        console.error('Error fetching classes:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.post('/classes', async (req, res) => {
    try {
        const { name } = req.body;

        if (!name) {
            return res.status(400).json({ error: 'Class name is required' });
        }

        await queryDatabase('INSERT INTO classes (name) VALUES (?)', [name]);

        res.status(201).json({ message: 'Class created successfully' });
    } catch (error) {
        console.error('Error creating class:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.get('/classes/:classId/students', async (req, res) => {
    try {
        const { classId } = req.params;
        const students = await queryDatabase('SELECT * FROM students WHERE class_id = ?', [classId]);
        res.json(students);
    } catch (error) {
        console.error('Error fetching students:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});



app.post('/grades', async (req, res) => {
    try {
        const { student_id, grade, weight, description } = req.body;

        if (!student_id || grade === undefined || weight === undefined || !description) {
            return res.status(400).json({ error: 'All fields are required' });
        }

        await queryDatabase('INSERT INTO grades (student_id, grade, weight, description) VALUES (?, ?, ?, ?)', [student_id, grade, weight, description]);

        res.status(201).json({ message: 'Grade added successfully' });
    } catch (error) {
        console.error('Error adding grade:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.get('/students/:studentId/grades', async (req, res) => {
    try {
        const { studentId } = req.params;
        const grades = await queryDatabase('SELECT id, grade, weight, description FROM grades WHERE student_id = ?', [studentId]);
        res.json(grades);
    } catch (error) {
        console.error('Error fetching grades:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});


app.get('/students/:studentId/average', async (req, res) => {
    try {
        const { studentId } = req.params;
        const grades = await queryDatabase('SELECT grade FROM grades WHERE student_id = ?', [studentId]);
        
        if (grades.length === 0) {
            return res.json({ average: 0 });
        }
        
        const total = grades.reduce((sum, grade) => sum + grade.grade, 0);
        const average = total / grades.length;

        res.json({ average: parseFloat(average.toFixed(2)) });
    } catch (error) {
        console.error('Error calculating average grade:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.delete('/students/:studentId', async (req, res) => {
    try {
        const { studentId } = req.params;

        await queryDatabase('DELETE FROM grades WHERE student_id = ?', [studentId]);

        await queryDatabase('DELETE FROM students WHERE id = ?', [studentId]);

        res.status(204).send();
    } catch (error) {
        console.error('Error deleting student:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.delete('/grades/:gradeId', async (req, res) => {
    try {
        const { gradeId } = req.params;

        await queryDatabase('DELETE FROM grades WHERE id = ?', [gradeId]);

        res.status(204).send();
    } catch (error) {
        console.error('Error deleting grade:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.post('/register', async (req, res) => {
    const { username, password, role, class_id } = req.body;

    if (!username || !password || !role) {
        return res.status(400).json({ error: 'All fields are required' });
    }

    try {
        const hashedPassword = await bcrypt.hash(password, 10);
        const query = 'INSERT INTO users (username, password, role, class_id, is_approved) VALUES (?, ?, ?, ?, ?)';
        await queryDatabase(query, [username, hashedPassword, role, class_id || null, role === 'student' ? false : true]);

        res.status(201).json({ message: 'User registered successfully. Await teacher approval if you are a student.' });
    } catch (error) {
        console.error('Error registering user:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});


app.post('/login', async (req, res) => {
    const { username, password } = req.body;

    try {
        const [user] = await queryDatabase('SELECT * FROM users WHERE username = ?', [username]);
        
        if (!user) {
            return res.status(400).json({ error: 'Invalid credentials' });
        }

        if (!user.is_approved) {
            return res.status(400).json({ error: 'Approval pending.' });
        }

        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(400).json({ error: 'Invalid credentials' });
        }

        const token = jwt.sign({ userId: user.id, role: user.role }, 'your_jwt_secret', { expiresIn: '1h' });
        res.json({ token });
    } catch (error) {
        console.error('Error logging in:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});



app.post('/approve/:userId', async (req, res) => {
    try {
        const { userId } = req.params;
        await queryDatabase('UPDATE users SET is_approved = TRUE WHERE id = ?', [userId]);
        res.json({ message: 'User approved' });
    } catch (error) {
        console.error('Error approving user:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

  





const PORT = 3001; 
app.listen(PORT, () => {
    console.log(`Server běží na portu ${PORT}`);
});
